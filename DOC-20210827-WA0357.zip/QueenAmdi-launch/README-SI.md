#### Select your language
  [![English](https://img.shields.io/badge/Select-English-red.svg)](https://github.com/BlackAmda/QueenAmdi/blob/launch/README.md)
  [![Sinhala](https://img.shields.io/badge/Select-Sinhala-green.svg)](https://github.com/BlackAmda/QueenAmdi/blob/launch/README-SI.md)
<div align="center">
  <img src="https://i.ibb.co/r3wmpwr/LOGO.jpg" width="300" height="300">
  <h1>👸💎 QUEEN AMDI BOT 💎👸</h1>
</div>
<p align="center">
    Whatsapp භාවිතා කිරීම පහසු සහ විනෝදජනක කරයි. Whatsapp සඳහා පළමු සිංහල පරිශීලක බොට් ද වේ.
    <br>
        <a href="https://chat.whatsapp.com/LYk6el7Ief41N2ypxVqcXD">Whatsapp Group</a> |
        <a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ">Youtube Channel</a>
    <br>
</p>

----

<p align="center">
  <a href="https://github.com/BlackAmda/QueenAmdi"><img alt="GitHub Clones" src="https://img.shields.io/badge/dynamic/json?style=flat-square&label=Docker pulls&query=count&url=https://github.com/agentnox/8gh32jk565/blob/main/automated_repo.json?raw=True&logo=github"></a>
  
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square&logo=github&label=Image Size">
    
  </a>
</p>

<p align="center">

  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FBlackAmda%2FQueenAmdi&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/fork">
    <img src="https://img.shields.io/github/forks/BlackAmda/QueenAmdi?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/stargazers">
    <img src="https://img.shields.io/github/stars/BlackAmda/QueenAmdi?style=social">
  </a>
</p>

<p align="center">
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/repo-size/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/license/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=License&style=plastic">

  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/languages/top/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/static/v1?label=Author&message=Black%20Amda&color=purple&style=plastic">

  </a>
  </p>
 <p align="center">
  <a href="https://wa.me/94757405652">
    <img src="https://img.shields.io/badge/Contact%20Me%20On%20Whatsapp-Queen%20Amdi%20Bot-purple&style=plastic">

  </a>
</p>

```
Queen Amdi බොට් යනු WhatsApp සඳහා වන පරිශීලක බොට් එකක් වන අතර එමඟින් ඔබට බොහෝ කාර්යයන් ඉටු කිරීමට ඉඩ සලසයි.
අනිසි ලෙස භාවිතා කිරීමේ සියලු ප්‍රතිවිපාක සඳහා පරිශීලකයා වගකිව යුතුය.
මෙය විවෘත මූලාශ්‍ර ව්‍යාපෘතියක් නොවේ. මෙය බොට් යෙදවීමට ඔබට ඉඩ සලසන ව්‍යාපෘතියක් පමණි.
ඊට අමතරව, එය පරිශීලකයින් සඳහා plugin සහාය සක්‍රීය කරයි.
මුල් මෘදුකාංගයට තමන්ගේම plugin සවි කර තමන්ට කැමති පරිදි භාවිතා කරන්න.
භාවිතය සම්පුර්ණයෙන්ම පරිශීලකයාගේ වගකීමකි. මෙහෙයුම් පද්ධතිය වගකිව යුතු නොවේ.
විනොද වෙන්න!
```

## Queen Amdi bot විශේෂාංග
Queen Amdi bot විශේෂාංග මෙන්න.
<a href="https://gist.github.com/BlackAmda/28493a9b3e4f6f7ade7774a68b7c1c05">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">

  </a>

නව යාවත්කාලීන කිරීම් බැලීමට මෙය ක්ලික් කරන්න(2.9v Updates). 
<a href="https://gist.github.com/BlackAmda/890b6b31fcb8d376d6a68afcb7359324">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">

  </a>


## 📢 Guide
> [Public group.](https://chat.whatsapp.com/LYk6el7Ief41N2ypxVqcXD) (New)

> [සිංහල tutorial](https://www.youtube.com/watch?v=mksNihEYSXs&ab_channel=D_KTWorld_%C2%A9)

## 🔎 Queen Amdi bot යනු කුමක්ද?
**Queen Amdi Bot,** WhatsApp උදව් බොට් කෙනකි.

## Setup

### සරල ක්‍රමය
#### 01. Click Run on Repl.it (Computer users) and Run the qr generator by clicking play button.

[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@BlackAmda/Queen-Amdi-QR-Code)

#### ඔබ ජංගම ජංගම දුරකථන භාවිතා කරන්නෙක් නම්. Termux භාවිතා කිරීමෙන් ඔබට QR කේතය ලබා ගත හැකිය. (Android පමනි. IOS භාවිතා කරන්නන්ට repl.it button භාවිතා කළ යුතුය)

Termux:

$ `bash <(curl -L https://t.ly/j0CU)`

`Queen Amdi bot ගොඩනැගීමට ඔබට ජංගම දුරකථන 2 ක් අවශ්‍ය වේ!
ඔබ දෙවන උපාංගයෙන් bot ක්‍රියා කරනු ඇත. 
ඔබ පළමු උපාංගය සමඟ පමණක් QR කේතය generate කරනු ඇත.
පළමු උපාංගයෙන් ඔබට Queen Amdi Bot install කිරීමට අවශ්‍යයි.`

#### 02. Click Deploy button

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/BlackAmda/QueenAmdi)

AN Tech Official Youtube Channel : https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ

## F.A.Q
නිතර අසන ප්‍රශ්න කිහිපයකට පිළිතුරු සපයන්න;
### ඔබට මගේ පණිවිඩ කියවිය හැකිද??
මෙම ව්‍යාපෘතිය විවෘත කේතයක් බැවින් සියලු කේත පැහැදිලි වේ. අඩු හෝ වැඩි නොවේ; ඔබට අවශ්‍ය දේ බැලීමට ඔබට හැකිය. **අපට ඔබගේ ගිණුම් වලට ප්‍රවේශයක් නොමැත.**

### අපේ ආරක්ෂාව ගැන කුමක් කිව හැකිද?
ඔබ ආරක්ෂාව ගැන සැලකිලිමත් වන්නේ නම්, ඔබට එය ඔබේම පරිගණකයකින් install කළ හැකිය. වෙනත් අයෙකු ඔබගේ දත්ත ග්‍රහණය කර ගෙන ඇතැයි ඔබ සිතන්නේ නම්, **Whatsapp> Three Dots> Whatsapp Web> Logout**.

### මෙම බොට් ගෙවිය යුතුද?
**ඇත්ත වශයෙන්ම නැත.** එය කිසි විටෙකත් සිදු නොවේ. නමුත් ඔබට අපට donation කළ හැකිය. You can reach me via [Whatsapp](https://wa.me/94757405652) .

විස්තර සහිත සියලුම විධාන මෙන්න. [GistHub](https://gist.github.com/BlackAmda/28493a9b3e4f6f7ade7774a68b7c1c05)

## සැමට ස්තූතියි! 
### අපි ඔබව සැමවිටම මතක තබා ගන්නෙමු..

### ⚠️ Warning! 
```
පරිශීලක බොට් නිසා; ඔබගේ WhatsApp ගිණුම banned කළ හැකිය.
මෙය විවෘත මූලාශ්‍ර ව්‍යාපෘතියකි, ඔබ කරන සෑම දෙයකටම ඔබ වගකිව යුතුය. 
නියත වශයෙන්ම, Queen Amdi විධායකයන් වගකීම භාර නොගනී.
Queen Amdi Bot පිහිටුවීමෙන් ඔබ මෙම වගකීම් භාරගෙන ඇති බව සලකනු ලැබේ.
```

## Developers

[![Black Amda](https://github.com/BlackAmda.png?size=100)](https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ)

[Black Amda](https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ)

## බලපත්රය
මෙම ව්‍යාපෘතිය `GNU General Public License v3.0` බලපත්රයෙන් ආරක්ෂා කර ඇත.
ප්‍රකාශන හිමිකම් පණිවිඩ සංස්කරණය නොකරන්න!

### Disclaimer
`WhatsApp` name, එහි වෙනස්කම් සහ ලාංඡනය ෆේස්බුක් හි ලියාපදිංචි වෙළඳ ලකුණු වේ. ලියාපදිංචි වෙළඳ ලකුණ සමඟ අපට කිසිදු සම්බන්ධයක් නැත.
