#### Select your language
  [![English](https://img.shields.io/badge/Select-English-red.svg)](https://github.com/BlackAmda/QueenAmdi/blob/launch/README.md)
  [![Sinhala](https://img.shields.io/badge/Select-Sinhala-green.svg)](https://github.com/BlackAmda/QueenAmdi/blob/launch/README-SI.md)
<div align="center">
  <img src="https://i.ibb.co/r3wmpwr/LOGO.jpg" width="300" height="300">
  <h1>👸💎 QUEEN AMDI BOT 💎👸</h1>
</div>
<p align="center">
    Makes it easy and fun to use WhatsApp. It is also the first Sinhala user bot for WhatsApp.
    <br>
        <a href="https://chat.whatsapp.com/LYk6el7Ief41N2ypxVqcXD">Whatsapp Group</a> |
        <a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ">Youtube Channel</a>
    <br>
</p>

----

<p align="center">
  <a href="https://github.com/BlackAmda/QueenAmdi"><img alt="GitHub Clones" src="https://img.shields.io/badge/dynamic/json?style=flat-square&label=Docker pulls&query=count&url=https://github.com/agentnox/8gh32jk565/blob/main/automated_repo.json?raw=True&logo=github"></a>
  
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square&logo=github&label=Image Size">
    
  </a>
</p>

<p align="center">

  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FBlackAmda%2FQueenAmdi&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/fork">
    <img src="https://img.shields.io/github/forks/BlackAmda/QueenAmdi?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/stargazers">
    <img src="https://img.shields.io/github/stars/BlackAmda/QueenAmdi?style=social">
  </a>
</p>

<p align="center">
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/repo-size/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/license/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=License&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/languages/top/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/static/v1?label=Author&message=Black%20Amda&color=purple&style=plastic">

  </a>
  </p>
 <p align="center">
  <a href="https://wa.me/94757405652">
    <img src="https://img.shields.io/badge/Contact%20Me%20On%20Whatsapp-Queen%20Amdi%20Bot-purple&style=plastic">

  </a>
</p>

```
Queen Amdi bot is an UserBot for WhatsApp That allowing you to get done so many tasks.
The user is responsible for all possible consequences of misuse.
This is not a Open-Source project. This is just a project that allow you to get deploy a bot.
Additionally, it enables plug-in support for users.
Install their own plugins to the original software and use as they please.
Usage is entirely the responsibility of the user. The operating system is not responsible.
HAVE A FUN!
```

## Queen Amdi bot features
Here is the Queen Amdi bot features.
<a href="https://gist.github.com/BlackAmda/28493a9b3e4f6f7ade7774a68b7c1c05">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">

  </a>

Click here to see the latest updates (2.9v update). 
<a href="https://gist.github.com/BlackAmda/890b6b31fcb8d376d6a68afcb7359324">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">

  </a>


## 📢 Guide
> [Public Bot Group](https://chat.whatsapp.com/LYk6el7Ief41N2ypxVqcXD) (New)

> [Sinhala tutorial](https://www.youtube.com/watch?v=mksNihEYSXs&ab_channel=D_KTWorld_%C2%A9)

## 🔎 What is Queen Amdi Bot?
**Queen Amdi Bot,** is a WhatsApp userbot like Telegram bot.

## Setup

### Easy Method
#### 01. Click Run on Repl.it (Computer users) and Run the qr generator by clicking play button.

[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@BlackAmda/Queen-Amdi-QR-Code)

#### If you are a mobile phone user. You can get the QR code using Termux. (Android only. IOS users must use the repl.it button)

Termux:

$ `bash <(curl -L https://t.ly/j0CU)`

`You need 2 mobile phones to build the Queen Amdi bot!
You will run the bot from the second device.
You will only generate a QR code with the first device.
From the first device you need to install Queen Amdi Bot.`

#### 02. Click Deploy button

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/BlackAmda/QueenAmdi)

AN Tech Official Youtube Channel : https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ

## F.A.Q
Answer a few frequently asked questions;
### Can you read my messages???
Since this project is open source, all codes are clear. Not more or less; You can see what you want. **Your accounts are not accessible.**

### What about our security?
If you are concerned about security, you can install it on your own computer. If you think someone else has taken over your data, **Whatsapp> Three Dots> Whatsapp Web> Logout**.

### Do these bots have to pay??
**Of course not.** It never happens. But you can donate to us. You can reach me via [Whatsapp](https://wa.me/94757405652) .

Here are all the commands with details. [GistHub](https://gist.github.com/BlackAmda/28493a9b3e4f6f7ade7774a68b7c1c05)

## Thanks everyone! 
### We will always remember you..

### ⚠️ Warning! 
```
Because of user bots; Your WhatsApp account can be banned.
This is an open source project, you are responsible for everything you do.
Certainly, Queen Amdi executives do not take responsibility.
By setting up Queen Amdi Bot you are considered to have assumed these responsibilities.
```

## Developers

[![Black Amda](https://github.com/BlackAmda.png?size=100)](https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ)

[Black Amda](https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ)

## License
This project is protected by the `GNU General Public License v3.0.`
Do not edit copyright messages!

### Disclaimer
`WhatsApp` name, its variations and logo are registered trademarks on Facebook. We have nothing to do with the registered trademark.
